module.exports.home= function(req,res)
{
    res.render('./startPage')
}